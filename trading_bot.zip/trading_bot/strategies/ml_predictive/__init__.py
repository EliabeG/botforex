# strategies/news_aware/__init__.py
"""Estratégias sensíveis a notícias"""
__all__ = []

# ===================================