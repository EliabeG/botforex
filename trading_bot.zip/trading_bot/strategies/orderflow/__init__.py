# strategies/orderflow/__init__.py
"""Estratégias baseadas em order flow"""
__all__ = []

# ===================================