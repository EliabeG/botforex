# strategies/overnight_carry/__init__.py
"""Estratégias de overnight carry"""
__all__ = []

# ===================================