# strategies/overnight_carry/__init__.py
"""Estratégias de overnight carry e rolagem de swap.""" # Descrição ajustada

# Importe suas classes de estratégia de Overnight Carry aqui quando forem criadas.
# Exemplo:
# from .basic_carry_trade_strategy import BasicCarryTradeStrategy

__all__ = [
    # 'BasicCarryTradeStrategy', # Adicionar ao __all__ quando a estratégia for implementada
]

# ===================================