# strategies/arbitrage/__init__.py
"""Estratégias de arbitragem estatística"""
__all__ = []

# ===================================