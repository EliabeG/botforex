# strategies/breakout/__init__.py
"""Estratégias de breakout"""

from .donchian_breakout import DonchianBreakoutStrategy
# Adicione outras estratégias de breakout aqui se existirem
# from .outra_estrategia_breakout import OutraEstrategiaBreakout

__all__ = [
    'DonchianBreakoutStrategy',
    # 'OutraEstrategiaBreakout',
    ]

# ===================================