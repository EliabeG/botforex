# strategies/breakout/__init__.py
"""Estratégias de breakout"""
__all__ = []

# ===================================