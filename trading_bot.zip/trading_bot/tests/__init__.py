# tests/__init__.py
"""Módulo de testes"""
import pytest

# Configurações de teste
pytest.register_assert_rewrite('tests.fixtures')

# ===================================